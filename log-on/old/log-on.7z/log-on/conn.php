<?php
	$conn = mysql_connect("localhost", "updayte", "dN6UFR8GC6K6LYax");
	mysql_select_db("updayte");
?>