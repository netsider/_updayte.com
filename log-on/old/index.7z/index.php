	<h1>Login with Facebook,Twitter & Google</h1>
<?php
echo '<a href="' . $_SERVER['PHP_SELF'] . '?provider=Google"><img src='google.png'></img></a><br><br>';
?>

